/usr/lib/resolsetter_gui/ressetter
