#!/bin/bash
tarjetasConectadas=$(xrandr -q | grep '\bconnected\b' | cut -d " " -f 1)

if [ -e ~/.siatic-ncmodeline/modeline-cfg ]; then
	currentModeline=$(cat ~/.siatic-ncmodeline/modeline-cfg)
else
	#Se ajusta una resolucion por defecto
	currentModeline="118.25 1600 1696 1856 2112 900 903 908 934"
fi

modeName=forceMode
modeName+=$(date +"%T")
while read -r line; do
	xrandr --newmode $modeName $currentModeline -hsync +vsync
	xrandr --addmode $line $modeName
	xrandr --output $line --mode $modeName
	echo "Setting modeline for output $line"
done <<< "$tarjetasConectadas"

# Ahora se reinicia Pandectas...
loop_bnd=10
while [ $(pidof Pandectas | wc -c ) -eq 0 ]; do
	if (( loop_bnd == 0 )); then
		echo "Se ha pasado el limite de espera"
		break
	fi
	let "loop_bnd=loop_bnd-1"
        echo "Esperando proceso a arrancar..."
        sleep 1
done
killall -9 Pandectas
pandectas >& /dev/null &
echo "El script ha finalizado su ejecucion"
